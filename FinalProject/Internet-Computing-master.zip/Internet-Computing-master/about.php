<?php
session_start()
?>
<!DOCTYPE html>
<html>
	<head>
		<title>About Page</title>
	</head>
	<body>
		<!-- This code wil be present on all the pages on the site. -->
		<?php include "nav.php"?>
		<!-- ****************************************************** -->
		<!-- Rest of the HTML code goes here. -->
		<center><h1>About Us</h1></center>
		<center><p>We are a computer company focused on providing the highest quality products for the best price possible. We specialize in coumputer
			hardware products, specifically motherboards, GPUs, CPUs, Power Supplies, and processors. Many of the products offered on our site are trusted
			brand name companies.  Our offices are located in centeral New Jersey and can be reached by phone Monday - Friday from 9am - 5pm EST. We offer
			competitive offers on all of our products a 60 day money back garrentee. We also partner with suppliers globally in order to provide quick shipping
		whereever you are. </p><center>
		<table>
			<tbody>
				<tr>
					<td><img src= "photos/GTX 1080ti.jpg" alt="GTX 1080 Ti graphics card" length="400" width="400"></td>
					<td><img src= "photos/7700K.jpg" alt="Intel i7 7700k Processor" length="400" width="400"></td>
					<td><img src= "photos/z270.jpg" alt="MSI z270 motherboard" length="400" width="400"></td>
				</tr>
			</tbody>
		</table>
		
	</body>
</html>