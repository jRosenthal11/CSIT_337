<?php
require 'config.php';
session_start();
$adduser_error = '';
if($_SESSION['logged'] == TRUE && $_SESSION['level'] == '1'){
$userid = $_SESSION['userid'];
$stmt = $connection->prepare("SELECT * FROM users WHERE userid='$userid'");
$stmt->execute();
$result = $stmt->fetchAll();
foreach ($result as $result){
$_SESSION['userid'] == $result['userid'];
}
}else{
session_destroy();
unset($_SESSION['email']);
header("Location: login.php");
}
if(isset($_POST['adduser_submit'])){
$additem_itemid = $_POST['additem_itemid'];
$additem_catid = $_POST['additem_catid'];
$additem_code = $_POST['additem_code'];
$additem_name = $_POST['additem_name'];
$additem_description = $_POST['additem_description'];
$additem_listprice = $_POST['additem_listprice'];
try {
$adduser_stmt = $connection->prepare("SELECT COUNT(*) FROM products WHERE productid = '$additem_itemid'");
$adduser_stmt->execute();
$adduser_result = $adduser_stmt->fetchColumn();
} catch (\Exception $e) {
$error = "Error: " . $e;
}
if ($adduser_result == 1) {
$adduser_error = ('This item ID already exists.');
} else {
$adduser_stmt1 = $connection->prepare("INSERT INTO products (productid, categoryID, productCode, productName, description,listPrice)
VALUES ('$additem_itemid', '$additem_catid', '$additem_code', '$additem_name', '$additem_description','$additem_listprice')");
$adduser_stmt1->execute();

header("Location: admin-panel.php");
}
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Add Item</title>
  </head>
  <body>
    <!-- This code wil be present on all the pages on the site. -->
    <?php include "nav.php"?>
    <!-- ****************************************************** -->
  
    <dir align = "center">
    <h3>products Table</h3>
  
    </dir>
    <div>
      <form action="" method="POST">
        <table align="center">
          <tr>
            <td>Product ID: </td>
            <td><input type="text" name="additem_itemid" required></td>
          </tr>
          <tr>
            <td>Category ID : </td>
            <td><input  type="text" name="additem_catid" required></td>
          </tr>
          <tr>
            <td>Product Code : </td>
            <td><input  type="text" name="additem_code" required></td>
          </tr>
          <tr>
            <td>Product Name : </td>
            <td><input  type="text" name="additem_name" required></td>
          </tr>
          <tr>
            <td>Description: </td>
            <td><input  type="text" name="additem_description" required></td>
          </tr>
               <td>list Price: </td>
            <td><input  type="text" name="additem_listprice" required></td>
          </tr>
          <tr align="center">
            <td colspan="2"><input type="submit" name="adduser_submit" value="Add Item"><a href="admin-panel.php"><input type="button" name="Back to admin-panel" value="Back to admin-panel"></td></a>
          </tr>
        </table>
        <h4 align="center" style="color: red; text-decoration: underline;"><?php echo $adduser_error; ?></h4>
      </form>
    </div>
  </body>
</html>