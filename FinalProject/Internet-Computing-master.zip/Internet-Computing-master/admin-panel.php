<?php include 'admincheck.php' ?>
<html>
  <head>
    <title>Welcome to LAN Store.</title>
    <link href="style.css" rel="stylesheet" type="text/css">
  </head>
  <body id="body">
    <!-- This code wil be present on all the pages on the site. -->
    <?php include "nav.php"?>
    <!-- ****************************************************** -->
    <!-- Rest of the HTML code goes here. -->
    <div align="center">
      <h3>Users Table</h3>
      <p>Level 1: Admin || Level 2: Manager || Level 3: Employee || Level 4: Customer</p>
      <table id="admintable">
        <tr>
          <th>User-ID</th>
          <th>Username</th>
          <th>First-Name</th>
          <th>Last-Name</th>
          <th>Level</th>
          <th>View User</th>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM users");
        $stmt->execute();
        $result1 = $stmt->fetchAll();
        foreach ($result1 as $result1){
        ?>
        <tr>
          <td><?php echo $result1['userid']; ?></td>
          <td><?php echo $result1['username']; ?></td>
          <td><?php echo $result1['firstname']; ?></td>
          <td><?php echo $result1['lastname']; ?></td>
          <td><?php echo $result1['level']; ?></td>
          <td><a href="user.php?userid=<?php echo $result1['userid'];?>"><input type="button" name="View" value="View"></a></td>
        </tr>
        <?php
        }
        ?>
      </table>
      <p align="center"><a href="adduser.php"><input type="button" name="adduser" value="Add-User"></p></a>
    </div>
    <div align="center">
      <h3>Product Table</h3>
     
      <table id="admintable">
        <tr>
          <th>Product-ID</th>
          <th>Product Code </th>
          <th>Product-Name</th>
          <th>Description</th>
          <th>Price</th>
          <th>View Item</th>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM products");
        $stmt->execute();
        $result1 = $stmt->fetchAll();
        foreach ($result1 as $result1){
        ?>
        <tr>
          <td><?php echo $result1['productid']; ?></td>
          <td><?php echo $result1['productCode']; ?></td>
          <td><?php echo $result1['productName']; ?></td>x
          <td><?php echo $result1['description']; ?></td>
          <td><?php echo $result1['listPrice']; ?></td>
          <td><a href="items.php?productid=<?php echo $result1['productid'];?>"><input type="button" name="View" value="View"></a></td>
        </tr>
        <?php
        }
        ?>
      </table>
      <p align="center"><a href="additem.php"><input type="button" name="additem" value="Add-Item"></p></a>
    </div>
  </body>
</html>