<?php
session_start();
require 'config.php';
if($_SESSION['logged'] == TRUE && $_SESSION['level'] == '1'){
  $userid = $_SESSION['userid'];
  
  $stmt = $connection->prepare("SELECT * FROM users WHERE userid='$userid'");
  $stmt->execute();
  $result = $stmt->fetchAll();
  foreach ($result as $result){
    $_SESSION['userid'] == $result['userid'];
    }
}else{
  session_destroy();
  unset($_SESSION['email']);
  header("Location: login.php");
}
?>