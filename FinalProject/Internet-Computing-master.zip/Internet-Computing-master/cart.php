<?php
require 'config.php';
session_start();
if ( $_SESSION['logged'] == true ) {
	if ( isset( $_GET['cart_id'] ) ) {
		$stmt   = $connection->prepare( "DELETE FROM cart where cartid = {$_GET['cart_id']}" );
		$stmt->execute();
		header('Location:cart.php');
	}
	$userid = $_SESSION['userid'];
	$stmt   = $connection->prepare( "SELECT * FROM users WHERE userid='$userid'" );
	$stmt->execute();
	$result = $stmt->fetchAll();
	foreach ( $result as $result ) {
		$_SESSION['userid'] == $result['userid'];
	}
} else {
	session_destroy();
	unset( $_SESSION['email'] );
	header( "Location: login.php" );
}
?>
<html>
	<head>
	</head>
	<body id="body">
		<!-- This code wil be present on all the pages on the site. -->
		<?php include "nav.php" ?>
		<div align="center">
			<table width="75%" border="1">
				<thead>
					<tr>
						<td><strong>Item Name</strong></td>
						<td><strong>Price</strong></td>
						<td><strong>Quantity</strong></td>
						<td><strong>Action</strong></td>
					</tr>
				</thead>
				<tbody>
					<?php
					$total = 0;
					if ( $_SESSION['logged'] == true ) {
						//Fetch Cart data of the user
						$userid = $_SESSION['userid'];
						$stmt1  = $connection->prepare( "SELECT * FROM cart WHERE user_id = $userid" );
						$stmt1->execute();
						$result2 = $stmt1->fetchAll();
						$total   = 0;
						foreach ( $result2 as $item ) {
							$total += floatval( $item['price'] * $item['qty'] );
					?>
					<tr>
						<td><?= $item['itemname'] ?></td>
						<td>$<?= $item['price'] * $item['qty'] ?></td>
						<td><?= $item['qty'] ?></td>
						<td><a href="cart.php?&cart_id=<?= $item['cartid'] ?>">Delete</a></td>
					</tr>
					<?php
					}
					}
					?>
				</tbody>
			</table>
			<a href="checkout.php">
			<input type="submit" name="checkout" value="Go to Checkout" ></a></td>
			<div style="margin-left: 37%">
				<div>-------------------------------------------</div>
				Total: <span style="font-size: 18px; font-weight: bold;">$<?= $total ?></span>
			</div>
		</div>
	</body>
</html>