<?php
require 'config.php';
session_start();
if ( $_SESSION['logged'] == true ) {
	if ( isset( $_GET['cart_id'] ) ) {
		$stmt   = $connection->prepare( "DELETE FROM cart where cartid = {$_GET['cart_id']}" );
		$stmt->execute();
		header('Location:cart.php');
	}
	$userid = $_SESSION['userid'];
	$stmt   = $connection->prepare( "SELECT * FROM users WHERE userid='$userid'" );
	$stmt->execute();
	$result = $stmt->fetchAll();
	foreach ( $result as $result ) {
		$_SESSION['userid'] == $result['userid'];
	}
} else {
	session_destroy();
	unset( $_SESSION['email'] );
	header( "Location: login.php" );
}
?>
<!--- checkout page the when you input your information this will be posted into the processorder page  --->
<html>
	<head>
		<title>LAN Store</title>
	</head>
	<body>
		<?php include "nav.php"; ?>
		<body>
			<h1> Checkout Page</h1>
			<form action="processorder.php" method="post">
				<table border="0">
					<tr>
						<td>Your Name</td>
						<td align="left"><input type="text" name="Name" size="30" maxlength="30"/></td>
					</tr>
					<tr>
						<td>E-Mail </td>
						<td align="left"><input type="text" name="email" size="30" maxlength="30"/></td>
					</tr>
					<tr>
						<td>Address</td>
						<td align="left"><input type="text" name="address" size="30" maxlength="30"/></td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" value="Submit Order"/></td>
					</tr>
				</table>
			</form>
		</body>
	</html>