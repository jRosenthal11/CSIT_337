<?php
$dbhost = '18.223.228.3';
$dbuser = 'iw3htp';
$dbpass = 'password';
$db = 'csit337';

try{
    $connection = new PDO("mysql:host=$dbhost;dbname=$db", $dbuser, $dbpass);
    // set the PDO error mode to exception
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
}catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
}
?>