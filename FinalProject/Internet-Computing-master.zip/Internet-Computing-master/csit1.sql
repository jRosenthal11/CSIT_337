-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2018 at 07:51 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csit1`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartid` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `productid` varchar(11) NOT NULL,
  `itemname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cartid`, `user_id`, `price`, `qty`, `productid`, `itemname`) VALUES
(0, '1', 307, 3, '2', 'Intel Core i7-6700K'),
(0, '1', 43, 31, '30', 'Corsair CX550M');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categoryID` int(11) NOT NULL,
  `categoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categoryID`, `categoryName`) VALUES
(1, 'cpu'),
(2, 'gpu'),
(3, 'hdssd'),
(4, 'motherboard'),
(5, 'power'),
(6, 'ram');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productid` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `productCode` varchar(10) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `listPrice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productid`, `categoryID`, `productCode`, `productName`, `description`, `listPrice`) VALUES
(1, 1, '2700X', 'AMD Ryzen 7 2700X', 'speed = 4 cores = 8', '264.99'),
(2, 1, '6700X', 'Intel Core i7-6700K', 'speed = 4 cores = 4', '307.00'),
(3, 1, '4790X', 'Intel Core i7-4790K', 'speed = 4 cores = 4', '413.00'),
(4, 1, '1600X', 'AMD Ryzen 5 1600', 'speed = 3 cores = 6', '159.89'),
(5, 1, '8700X', 'Intel i7-8700K', 'speed = 4 cores = 6', '264.99'),
(6, 2, '2700X7', 'AMD Ryzen 7 2700X', 'speed = 4 cores = 8', '264.99'),
(7, 2, '6700K', 'Intel i7-6700K', 'speed = 4 cores = 4', '307.00'),
(8, 2, '4790K', 'Intel i7-4790K', 'speed = 4 cores = 4', '413.00'),
(9, 2, '1600K', 'AMD Ryzen 5 1600', 'speed = 3 cores = 6', '159.89'),
(10, 2, '8700K', 'Intel i7-8700K', 'speed = 4 cores = 6', '264.99'),
(11, 3, '1060', 'EVGA GeForce 1060', 'chip is GeForce 1060 with a memory of 6 and a speed of 1.607', '199.99'),
(12, 3, '580', 'MSI Radeon RX 580', 'chip is Radeon RX 580 with a memory of 8 and a speed of 1.257', '189.99'),
(13, 3, '1050', 'MSI GTX 1050 Ti Gaming', 'chip is GeForce GTX 1050 Ti with a memory of 4 and speed of 1.29', '169.99'),
(14, 3, '1060G', 'MSI GeForce 1060', 'chip is Geforce 1060 with a memory 6 and speed of 1.544', '239.99'),
(15, 3, '1060i', 'Asus STRIX GTX 1080Ti Gaming', 'chip is GeForce 1080Ti with a memory of  11 and speed of 1.493', '699.99'),
(16, 4, 'WD10EZEX', 'Western Digital WD10EZEX', ' has 1 TB size 64 GB of cache', '39.99'),
(17, 4, 'Sea', 'Seagate Barracuda', ' has 2 TB and 64 MB of cache', '58.89'),
(18, 4, '860', 'Samsung 860 Evo', 'has 500 GB 512 MB of cache', '72.99'),
(19, 4, '970', 'Samsung 970 Evo', 'has 500 GB 512 MB of Cache', '117.99'),
(20, 4, 'A400', 'Kingston A400', ' has 120 GB 64 MB of cache', '29.99'),
(21, 5, 'B350P', 'MSI B350 PC MATE', 'AM4 with 4 ram slots and  64 max ram', '59.99'),
(22, 5, 'B350', 'MSI B350 PC MATE', 'AM4 with 4 ram slots and  64 max ram', '59.99'),
(23, 5, 'B450M', 'Gigabyte B450M', 'AM4 with 4 ram slots and  64 max ram', '54.99'),
(24, 5, 'Z470', 'MSI Z470 Gaming Plus', 'AM4with 4 ram slots and  64 max ram', '94.99'),
(25, 5, 'Z370G', 'Asus ROG STRIX Z370 Gaming', ' Socket of LGA 1151 with 4 ram slots and  64 max ram', '99.99'),
(26, 6, '650', 'EVGA SuperNOVA 650', '650 watts', '59.99'),
(27, 6, '760', 'EVGA SuperNOVA 750', '750 watts', '89.71'),
(28, 6, '550', 'EVGA SuperNOVA 550', ' 550 watts', '82.89'),
(29, 6, '450M', 'Corsair CX450M', '450 watts', '29.99'),
(30, 6, '550M', 'Corsair CX550M', '550 watts', '42.99');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(255) NOT NULL,
  `username` varchar(21) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `firstname`, `lastname`, `password`, `level`) VALUES
(2, 'manager', 'manager', 'manager', 'manager', 2),
(3, 'user', 'user', 'user', 'user', 3),
(1, 'admin', 'admin', 'admin', 'admin', 1),
(0, 'david', 'david', 'david', 'david', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productid`),
  ADD UNIQUE KEY `productCode` (`productCode`),
  ADD KEY `categoryID` (`categoryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
