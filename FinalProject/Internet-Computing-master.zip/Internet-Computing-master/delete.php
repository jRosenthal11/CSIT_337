<?php include 'admincheck.php' ?>

<?php
$userid1 = $_GET['userview'];
echo "$userid1";
$stmt = $connection->prepare("DELETE FROM `users` WHERE `userid` = '$userid1'");
$stmt->execute();
header("Location: admin-panel.php");
?>

<?php
$itemid1 = $_GET['itemview'];
echo "$itemid1";
$stmt = $connection->prepare("DELETE FROM `products` WHERE `productid` = '$itemid1'");
$stmt->execute();

header("Location: admin-panel.php");
echo "deleted";
?>