<?php include 'usercheck.php' ?>
<html>
  <head>
    <title>Welcome to LAN Store.</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body id="body">
    <!-- This code wil be present on all the pages on the site. -->
    <?php include "nav.php"?>
    <!-- ****************************************************** -->
    <!-- Rest of the HTML code goes here. -->
  </body>
</html>