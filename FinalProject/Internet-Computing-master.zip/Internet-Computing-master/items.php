<?php
require 'config.php';
session_start();
$productid1 = $_GET['productid'];
if($_SESSION['logged'] == TRUE && $_SESSION['level'] == '1'){
	$userid = $_SESSION['userid'];
	$stmt = $connection->prepare("SELECT * FROM users WHERE userid='$userid'");
	$stmt->execute();
	$result = $stmt->fetchAll();
	foreach ($result as $result){
		$_SESSION['userid'] == $result['userid'];
		}
}else{
	session_destroy();
	unset($_SESSION['email']);
	header("Location: login.php");
}
/*  thos is connecting to the database and making sure that the user that is logged in is level 1 if it is not legel one then destroys session. If it is lebel one then everything below will be displayed */
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Edit User Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<!-- This code wil be present on all the pages on the site. -->
		<?php include "nav.php"?>
		<!-- ****************************************************** -->
		<!-- this connects from databse so that we can view items in the products table. Only the admin can see this and as such they can add and delete users  -->
		<?php
		$stmt1 = $connection->prepare("SELECT * FROM products WHERE productid = $productid1");
		$stmt1->execute();
		$result1 = $stmt1->fetchAll();
		foreach ($result1 as $result1){
			$_SESSION['userid2'] = $result1['productid'];
			$_SESSION['username'] = $result1['productCode'];
			$_SESSION['firstname'] = $result1['productName'];
			$_SESSION['lastname'] = $result1['description'];
			$_SESSION['level1'] = $result1['listPrice'];
			}
		?>
		<div align="center">
		
			<table id="utable">
				<tr>
					<td><b>Product-ID: </b></td>
					<td><?php echo $_SESSION['userid2'] ?></td>
				</tr>
				<tr>
					<td><b>Product Code: </b></td>
					<td><?php echo $_SESSION['username'] ?></td>
				</tr>
				<tr>
					<td><b> Name: </b></td>
					<td><?php echo $_SESSION['firstname'] ?></td>
				</tr>
				<tr>
					<td><b> description: </b></td>
					<td><?php echo $_SESSION['lastname'] ?></td>
				</tr>
				<tr>
					<td><b>Price: </b></td>
					<td><?php echo $_SESSION['level1'] ?></td>
				</tr>
			</table>
		</div>
		<div align="center">
			<a href="delete.php?itemview=<?php echo $_SESSION['userid2'];?>"><input type="button" name="View" value="Delete"></a>
			<a href="admin-panel.php"><input type="button" name="Back to admin-panel" value="Back to admin-panel"></td></a>
		</div>
	</body>
</html>