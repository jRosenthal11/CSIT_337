<?php
require 'config.php';
session_start();
$error = '';
if(isset($_POST['login'])){
  // Give username and password a var.
  $username = $_POST['email'];
  $password = md5($_POST['password']);
  $result2 = '';
  // Execute the SQL code so that it runs.
  try {
    $stmt1 = $connection->prepare("SELECT COUNT(*) FROM users WHERE username = '$username' AND md5 = '$password'");
    $stmt1->execute();
    $result1 = $stmt1->fetchColumn();
  } catch (\Exception $e) {
    $error = "Error: " . $e;
  }
  if ($result1 == 1) {
    $stmt2 = $connection->prepare("SELECT * FROM users WHERE username = '$username'");
    $stmt2->execute();
    $result2 = $stmt2->fetchAll();
    foreach ($result2 as $result2){
      $_SESSION['userid'] = $result2['userid'];
      $_SESSION['level'] = $result2['level'];
      $_SESSION['logged'] = TRUE;
    }
    header("Location: index.php");
  }else if ($username == '' || $password == '') {
    $error = "Enter a Username/Password!";
  }else {
    $error = "Incorret credentials";
  }
}
?>
<html>
  <head>
    <title>Login</title>
    <style type="text/css">
      div{
        margin-top: 200px;
      }
    </style>
  </head>
  <div align="center">
    <form action="" method="post">
      <h1>Welcome to LAN Store Login Page</h1>
      <h3>Please Login</h3>
      <table>
        <tr>
          <td>Email:</td>
          <td><input type="text" name="email" value="" autofocus></td>
        </tr>
        <tr>
          <td>Password:</td>
          <td><input type="password" name="password" value=""></td>
        </tr>
      </table>
      <h4 style="color: red; text-decoration: underline;"><?php echo $error; ?></h4>
      <p><input type="submit" name="login" value="Login"></p>
    </form>
    <h3>New to the site? Register Here :)</h3>
    <p><a href="register.php"><input type="submit" name="login" value="Register"></a></p>
  </div>
</html>