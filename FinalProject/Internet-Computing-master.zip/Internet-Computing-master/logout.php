<?php
session_start();
if ($_SESSION['logged'] == TRUE) {
    session_unset();
    session_destroy();
    session_write_close();
    header("Location: login.php");
}
?>