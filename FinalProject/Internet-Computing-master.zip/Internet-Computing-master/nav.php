<link rel="stylesheet" href="style.css">

<style type="text/css">
    a{
        text-decoration-style: none;
        text-decoration-line: none;
    }
</style>

<div id="main" align="center">
    <div>
        <h1><a href="index.php">LAN Store</a></h1>
        <p>Welcome to the LAN Store your one stop shop for everything computers related</p>
    </div>
    <nav>
        <ul id="nav">
            <li><a href='index.php'>Home</a></li>
            <li><a href='store.php'>Store</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <?php
            if($_SESSION['level'] == 1){
            ?>
            <li><a href='admin-panel.php'>Admin</a></li>
            <?php
            }
            ?>
            <li><a href="about.php">About</a></li>
            <li><a href="logout.php">Logout</a></li>

        </ul>
    </nav>
</div>