<?php
require 'config.php';
session_start();
if ( $_SESSION['logged'] == true ) {
	$userid = $_SESSION['userid'];
	$stmt   = $connection->prepare( "SELECT * FROM users WHERE userid='$userid'" );
	$stmt->execute();
	$result = $stmt->fetchAll();
	foreach ( $result as $result ) {
		$_SESSION['userid'] == $result['userid'];
	}
} else {
	session_destroy();
	unset( $_SESSION['email'] );
	header( "Location: login.php" );
}
?>
<?php
// create short variable names
$name = $_POST['Name'];
$email = $_POST['email'];
$address = $_POST['address'];

$date = date('H:i, jS F Y');
?>
<html>
	<head>
	</head>
	<body id="body">
		<!-- This code wil be present on all the pages on the site. -->
		<?php include "nav.php" ?>
		<div>
		<title>LAN store - Order Results</title>
	</head>
	<body>
		<h2>Order Results</h2>
		<table >
			Your Order
			<tr>
				<td><strong>Item Name</strong></td>
				<td><strong>Price</strong></td>
				<td><strong>Quantity</strong></td>
				
			</tr>
			<?php
			/* selects from database where the user is logged in and then selects their cart it will display their items and total then with the information posted from checkout.php it will echo out results */
					$total = 0;
					if ( $_SESSION['logged'] == true ) {
						//Fetch Cart data of the user
						$userid = $_SESSION['userid'];
						$stmt1  = $connection->prepare( "SELECT * FROM cart WHERE user_id = $userid" );
						$stmt1->execute();
						$result2 = $stmt1->fetchAll();
						$total   = 0;
						foreach ( $result2 as $item ) {
							$total += floatval( $item['price'] * $item['qty'] );
			?>
			<tr>
				<td><?= $item['itemname'] ?></td>
				<td>$<?= $item['price'] * $item['qty'] ?></td>
				<td><?= $item['qty'] ?></td>
				
			</tr>
			<?php
			}
			}
			?>
			<br>
		</tbody>
	</table>
	
	<div>-------------------------------------------</div>
	Total: <span style="font-size: 18px; font-weight: bold;"><?= $total ?></span>
</div>
</div></body>
<body>
<br><br>
<?php
// create short variable names
$name = $_POST['Name'];
$email = $_POST['email'];
$address = $_POST['address'];

$date = date('H:i, jS F Y');
?>
Thank you <?= $name?> for your order your total was $<?= $total ?> and will be shipped to <?= $address?> your email we have on file is <?= $email ?>
<br>
Order placed on  <?= $date?>
</html>