<?php
require 'config.php';
$adduser_error = '';
if(isset($_POST['adduser_submit'])){
  $adduser_username = $_POST['adduser_username'];
  $adduser_firstname = $_POST['adduser_firstname'];
  $adduser_lastname = $_POST['adduser_lastname'];
  $adduser_password = md5($_POST['adduser_password']);
  try {
    $adduser_stmt = $connection->prepare("SELECT COUNT(*) FROM users WHERE username = '$adduser_username'");
    $adduser_stmt->execute();
    $adduser_result = $adduser_stmt->fetchColumn();
  } catch (\Exception $e) {
    $error = "Error: " . $e;
  }
  if ($adduser_result == 1) {
    $adduser_error = ('This username already exists.');
  } else {
    $adduser_stmt1 = $connection->prepare("INSERT INTO users (username, firstname, lastname, md5, level)
                                           VALUES ('$adduser_username', '$adduser_firstname', '$adduser_lastname', '$adduser_password', '4')");
    $adduser_stmt1->execute();
    header("Location: login.php");
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Users</title>
</head>
<body>
  <!-- This code wil be present on all the pages on the site. -->
  <!-- ****************************************************** -->
  <div align="center">
    <h1>The LAN Store</h1>
    <p>Enter your information below to get started</p>
  </div>
  <!-- Rest of the HTML code goes here. -->
  <div>
    <form action="" method="POST">
      <table align="center">
      <tr>
        <td>Username: </td>
        <td><input type="text" name="adduser_username" required></td>
      </tr>
      <tr>
        <td>Firstname: </td>
        <td><input  type="text" name="adduser_firstname" required></td>
      </tr>
      <tr>
        <td>Lastname: </td>
        <td><input  type="text" name="adduser_lastname" required></td>
      </tr>
      <tr>
        <td>Password: </td>
        <td><input  type="password" name="adduser_password" required></td>
      </tr>
      <tr align="center">
        <td colspan="2"><input type="submit" name="adduser_submit" value="Register"></td>
      </tr>
    </table>
    <h4 align="center" style="color: red; text-decoration: underline;"><?php echo $adduser_error; ?></h4>
    </form>
  </div>
</body>
</html>