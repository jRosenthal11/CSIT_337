<?php include 'usercheck.php' ?>
<html>
  <head>
    <title>LAN Store</title>
  </head>
  <body>
    <?php include "nav.php"; ?>
    <div align="center" id ="productdiv">
      <h4>CPU</h4>
      <table id ="admintable">
        <tr>
          <td>Name</td>
          <td>Speed</td>
          <td>Cores</td>
          <td>Price</td>
          <td>Add to cart</td>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM cpu");
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $result1) {
        $result1['SKU']
        ?>
        <tr>
          <td><?= $result1['Name'] ?></td>
          <td><?= $result1['Speed'] ?> GHz</td>
          <td><?= $result1['Cores'] ?></td>
          <td>$ <?= $result1['Price'] ?></td>
          <td><a href="storeview.php?productid=<?php echo $result1['SKU'];?>-cpu"><input type="button" name="view" value="view"></a></td>
        </tr>
        <?php } ?>
      </table>
    </div>
    <div align="center" id ="productdiv">
      <h4>GPU</h4>
      <table id ="admintable">
        <tr>
          <td>Name</td>
          <td>Chipset</td>
          <td>Memory</td>
          <td>Speed</td>
          <td>Price</td>
          <td>Add to cart</td>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM gpu");
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $result1) {
        $result1['SKU']
        ?>
        <tr>
          <td><?= $result1['Name'] ?></td>
          <td><?= $result1['Chipset'] ?></td>
          <td><?= $result1['Memory'] ?> GB</td>
          <td><?= $result1['Speed'] ?> Ghz</td>
          <td>$ <?= $result1['Price'] ?></td>
          <td><a href="storeview.php?productid=<?php echo $result1['SKU'];?>-gpu"><input type="button" name="view" value="view"></a></td>
        </tr>
        <?php } ?>
      </table>
    </div>
    <div align="center" id ="productdiv">
      <h4>Motherboard</h4>
      <table id ="admintable">
        <tr>
          <td>Name</td>
          <td>Socket</td>
          <td>Ram-Slots</td>
          <td>Max-Ram</td>
          <td>Price</td>
          <td>Add to Cart</td>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM mb");
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $result1) {
        $result1['SKU']
        ?>
        <tr>
          <td><?= $result1['Name'] ?></td>
          <td><?= $result1['Socket'] ?></td>
          <td><?= $result1['Ramslots'] ?></td>
          <td><?= $result1['Maxram'] ?> GB</td>
          <td>$ <?= $result1['Price'] ?></td>
          <td><a href="storeview.php?productid=<?php echo $result1['SKU'];?>-mb"><input type="button" name="view" value="view"></a></td>
        </tr>
        <?php } ?>
      </table>
    </div>
    <div align="center" id ="productdiv">
      <h4>PSU</h4>
      <table id ="admintable">
        <tr>
          <td>Name</td>
          <td>Watts</td>
          <td>Price</td>
          <td>Add to cart</td>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM psu");
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $result1) {
        $result1['SKU']
        ?>
        <tr>
          <td><?= $result1['Name'] ?></td>
          <td><?= $result1['Watts'] ?></td>
          <td>$ <?= $result1['Price'] ?></td>
          <td><a href="storeview.php?productid=<?php echo $result1['SKU'];?>-psu"><input type="button" name="view" value="view"></a></td>
        </tr>
        <?php } ?>
      </table>
    </div>
    <div align="center" id ="productdiv">
      <h4>RAM</h4>
      <table id ="admintable">
        <tr>
          <td>Name</td>
          <td>Speed</td>
          <td>Type</td>
          <td>Size</td>
          <td>Price</td>
          <td>Add to cart</td>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM ram");
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $result1) {
        $result1['SKU']
        ?>
        <tr>
          <td><?= $result1['Name'] ?></td>
          <td><?= $result1['Speed'] ?></td>
          <td><?= $result1['Type'] ?></td>
          <td><?= $result1['Size'] ?> GB</td>
          <td>$ <?= $result1['Price'] ?></td>
          <td><a href="storeview.php?productid=<?php echo $result1['SKU'];?>-ram"><input type="button" name="view" value="view"></a></td>
        </tr>
        <?php } ?>
      </table>
    </div>
    <div align="center" id ="productdiv">
      <h4>SSD</h4>
      <table id ="admintable">
        <tr>
          <td>Name</td>
          <td>Size</td>
          <td>Cache</td>
          <td>Price</td>
          <td>Add to cart</td>
        </tr>
        <?php
        $stmt = $connection->prepare("SELECT * FROM ssd");
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $result1) {
        $result1['SKU']
        ?>
        <tr>
          <td><?= $result1['Name'] ?></td>
          <td><?= $result1['Size'] ?></td>
          <td><?= $result1['Cache'] ?></td>
          <td>$ <?= $result1['Price'] ?></td>
          <td><a href="storeview.php?productid=<?php echo $result1['SKU'];?>-ssd"><input type="button" name="view" value="view"></a></td>
        </tr>
        <?php } ?>
      </table>
    </div>
  </body>
</html>