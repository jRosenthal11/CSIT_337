<?php include 'usercheck.php' ?>
<?php
error_reporting( E_ALL );
ini_set( 'display_errors', 1 );
require 'config.php';
$product_id    = $_GET['productid'];
$pieces = explode("-", $product_id);
if ( isset( $_POST['add_cart'] ) ) {
	$quantity = intval( $_POST['qty'] );
	$id       = $_SESSION['storeview_sku'];
	$name     = $_SESSION['storeview_name'];
	$Price    = $_SESSION['storeview_price'];
	try {
		$q            = "SELECT * FROM cart WHERE productid = $id";
		$addcart_stmt = $connection->prepare( $q );
		$addcart_stmt->execute();
		$addcart_result = $addcart_stmt->fetch();
	} catch ( \Exception $e ) {
		$error = "Error: " . $e;
	}
	if ( $addcart_result > 1 ) {
		$addcart_error = ( 'Already in cart' );
		$existing_qty  = $addcart_result['qty'];
		$sql= "UPDATE cart SET qty = qty+$quantity WHERE productid = $id";
		$addcart_stmt1 = $connection->prepare( $sql );
		$addcart_stmt1->execute();
		print( "<center style='color: red;'> Added to cart" .  "</center>" );
	} else {
		$addcart_stmt1 = $connection->prepare( "INSERT INTO cart (productid,user_id,itemname,price,qty) VALUES ('$id',$userid, '$name',$Price,$quantity)" );
		$addcart_stmt1->execute();
		echo "updated to cart";
	}
}
?>
<html>
	<head>
		<title>Welcome to LAN Store.</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body id="body">
		<!-- This code wil be present on all the pages on the site. -->
		<?php include "nav.php" ?>
		<!-- ****************************************************** -->
		<!-- Rest of the HTML code goes here. -->
		<?php
		
		?>
		<div align="center">
			<?php
			$row = $pieces[0];
			if ($pieces[1] == 'cpu') {
				$stmt1 = $connection->prepare("SELECT * FROM cpu WHERE sku='$row'");
				$stmt1->execute();
				$result1 = $stmt1->fetchAll();
				foreach ($result1 as $result1) {
					$_SESSION['storeview_sku']  = $result1['SKU'];
					$_SESSION['storeview_name'] = $result1['Name'];
					$_SESSION['storeview_speed'] = $result1['Speed'];
					$_SESSION['storeview_cores']   = $result1['Cores'];
					$_SESSION['storeview_price'] = $result1['Price'];
					$_SESSION['storeview_picture'] = $result1['Picture'];
				}
			?>
			<div>
				<?php $image = $_SESSION['storeview_picture']; ?>
				<img width="250px" id="image" src="images/<?php echo $image; ?>.jpg">
			</div>
			<div align="center">
				<form action="" method="POST">
					<table id="utable">
						<tr>
							<td><b>SKU: </b></td>
							<td><?php echo $_SESSION['storeview_sku'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_name'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_speed'] ?></td>
						</tr>
						<tr>
							<td><b>Cores: </b></td>
							<td><?php echo $_SESSION['storeview_cores'] ?></td>
						</tr>
						<tr>
							<td><b>Price: </b></td>
							<td><?php echo $_SESSION['storeview_price'] ?></td>
						</tr>
						
						<td><b> QTY </b></td>
						<td>
							<input type="text" name="qty" value="">
						</table>
					</div>
					<div align="center">
					<td colspan="2"><input type="submit" name="add_cart" value="Add to cart"></td>
					<a href="store.php"><input type="button" name="back to store" value="back to store"></a>
				</div>
			<?php
			}
			?>
			
			<?php
			$row = $pieces[0];
			if ($pieces[1] == 'gpu') {
				$stmt1 = $connection->prepare("SELECT * FROM gpu WHERE sku='$row'");
				$stmt1->execute();
				$result1 = $stmt1->fetchAll();
				foreach ($result1 as $result1) {
					$_SESSION['storeview_sku']  = $result1['SKU'];
					$_SESSION['storeview_name'] = $result1['Name'];
					$_SESSION['storeview_chipset'] = $result1['Chipset'];
					$_SESSION['storeview_memory'] = $result1['Memory'];
					$_SESSION['storeview_speed'] = $result1['Speed'];
					$_SESSION['storeview_price'] = $result1['Price'];
					$_SESSION['storeview_picture'] = $result1['Picture'];
				}
			?>
			<div>
				<?php $image = $_SESSION['storeview_picture']; ?>
				<img width="250px" id="image" src="images/<?php echo $image; ?>.jpg">
			</div>
			<div align="center">
				<form action="" method="POST">
					<table id="utable">
						<tr>
							<td><b>SKU: </b></td>
							<td><?php echo $_SESSION['storeview_sku'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_name'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_chipset'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_memory'] ?></td>
						</tr>
						<tr>
							<td><b>Cores: </b></td>
							<td><?php echo $_SESSION['storeview_speed'] ?></td>
						</tr>
						<tr>
							<td><b>Price: </b></td>
							<td><?php echo $_SESSION['storeview_price'] ?></td>
						</tr>
						<tr>
							<td><b>Price: </b></td>
							<td><?php echo $_SESSION['storeview_picture'] ?></td>
						</tr>
						
						<td><b> QTY </b></td>
						<td>
							<input type="text" name="qty" value="">
						</table>
					</div>
					<div align="center">
					<td colspan="2"><input type="submit" name="add_cart" value="Add to cart"></td>
					<a href="store.php"><input type="button" name="back to store" value="back to store"></a>
				</div>
			<?php
			}
			?>
			
			<?php
			$row = $pieces[0];
			if ($pieces[1] == 'mb') {
				$stmt1 = $connection->prepare("SELECT * FROM mb WHERE sku='$row'");
				$stmt1->execute();
				$result1 = $stmt1->fetchAll();
				foreach ($result1 as $result1) {
					$_SESSION['storeview_sku']  = $result1['SKU'];
					$_SESSION['storeview_name'] = $result1['Name'];
					$_SESSION['storeview_socket'] = $result1['Socket'];
					$_SESSION['storeview_ramsolts'] = $result1['Ramsolts'];
					$_SESSION['storeview_maxram'] = $result1['Maxram'];
					$_SESSION['storeview_price'] = $result1['Price'];
					$_SESSION['storeview_picture'] = $result1['Picture'];
				}
			?>
			<div>
				<?php $image = $_SESSION['storeview_picture']; ?>
				<img width="250px" id="image" src="images/<?php echo $image; ?>.jpg">
			</div>
			<div align="center">
				<form action="" method="POST">
					<table id="utable">
						<tr>
							<td><b>SKU: </b></td>
							<td><?php echo $_SESSION['storeview_sku'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_name'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_socket'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_ramsolts'] ?></td>
						</tr>
						<tr>
							<td><b>Cores: </b></td>
							<td><?php echo $_SESSION['storeview_maxram'] ?></td>
						</tr>
						<tr>
							<td><b>Price: </b></td>
							<td><?php echo $_SESSION['storeview_price'] ?></td>
						</tr>
						<tr>
							<td><b>Price: </b></td>
							<td><?php echo $_SESSION['storeview_picture'] ?></td>
						</tr>
						
						<td><b> QTY </b></td>
						<td>
							<input type="text" name="qty" value="">
						</table>
					</div>
					<div align="center">
					<td colspan="2"><input type="submit" name="add_cart" value="Add to cart"></td>
					<a href="store.php"><input type="button" name="back to store" value="back to store"></a>
				</div>
			<?php
			}
			?>

			<?php
			$row = $pieces[0];
			if ($pieces[1] == 'psu') {
				$stmt1 = $connection->prepare("SELECT * FROM psu WHERE sku='$row'");
				$stmt1->execute();
				$result1 = $stmt1->fetchAll();
				foreach ($result1 as $result1) {
					$_SESSION['storeview_sku']  = $result1['SKU'];
					$_SESSION['storeview_name'] = $result1['Name'];
					$_SESSION['storeview_watts'] = $result1['Watts'];
					$_SESSION['storeview_price'] = $result1['Price'];
					$_SESSION['storeview_picture'] = $result1['Picture'];
				}
			?>
			<div>
				<?php $image = $_SESSION['storeview_picture']; ?>
				<img width="250px" id="image" src="images/<?php echo $image; ?>.jpg">
			</div>
			<div align="center">
				<form action="" method="POST">
					<table id="utable">
						<tr>
							<td><b>SKU: </b></td>
							<td><?php echo $_SESSION['storeview_sku'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_name'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_watts'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_price'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_picture'] ?></td>
						</tr>
						<td><b> QTY </b></td>
						<td>
							<input type="text" name="qty" value="">
						</table>
					</div>
					<div align="center">
					<td colspan="2"><input type="submit" name="add_cart" value="Add to cart"></td>
					<a href="store.php"><input type="button" name="back to store" value="back to store"></a>
				</div>
			<?php
			}
			?>

			<?php
			$row = $pieces[0];
			if ($pieces[1] == 'ram') {
				$stmt1 = $connection->prepare("SELECT * FROM ram WHERE sku='$row'");
				$stmt1->execute();
				$result1 = $stmt1->fetchAll();
				foreach ($result1 as $result1) {
					$_SESSION['storeview_sku']  = $result1['SKU'];
					$_SESSION['storeview_name'] = $result1['Name'];
					$_SESSION['storeview_speed'] = $result1['Speed'];
					$_SESSION['storeview_type'] = $result1['Type'];
					$_SESSION['storeview_size'] = $result1['Size'];
					$_SESSION['storeview_price'] = $result1['Price'];
					$_SESSION['storeview_picture'] = $result1['Picture'];
				}
			?>
			<div>
				<?php $image = $_SESSION['storeview_picture']; ?>
				<img width="250px" id="image" src="images/<?php echo $image; ?>.jpg">
			</div>
			<div align="center">
				<form action="" method="POST">
					<table id="utable">
						<tr>
							<td><b>SKU: </b></td>
							<td><?php echo $_SESSION['storeview_sku'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_name'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_speed'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_type'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_size'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_price'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_picture'] ?></td>
						</tr>
						<td><b> QTY </b></td>
						<td>
							<input type="text" name="qty" value="">
						</table>
					</div>
					<div align="center">
					<td colspan="2"><input type="submit" name="add_cart" value="Add to cart"></td>
					<a href="store.php"><input type="button" name="back to store" value="back to store"></a>
				</div>
			<?php
			}
			?>

			<?php
			$row = $pieces[0];
			if ($pieces[1] == 'ssd') {
				$stmt1 = $connection->prepare("SELECT * FROM ssd WHERE sku='$row'");
				$stmt1->execute();
				$result1 = $stmt1->fetchAll();
				foreach ($result1 as $result1) {
					$_SESSION['storeview_sku']  = $result1['SKU'];
					$_SESSION['storeview_name'] = $result1['Name'];
					$_SESSION['storeview_size'] = $result1['Size'];
					$_SESSION['storeview_cache'] = $result1['Cache'];
					$_SESSION['storeview_price'] = $result1['Price'];
					$_SESSION['storeview_picture'] = $result1['Picture'];
				}
			?>
			<div>
				<?php $image = $_SESSION['storeview_picture']; ?>
				<img width="250px" id="image" src="images/<?php echo $image; ?>.jpg">
			</div>
			<div align="center">
				<form action="" method="POST">
					<table id="utable">
						<tr>
							<td><b>SKU: </b></td>
							<td><?php echo $_SESSION['storeview_sku'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_name'] ?></td>
						</tr>
						<tr>
							<td><b>Name: </b></td>
							<td><?php echo $_SESSION['storeview_size'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_cache'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_price'] ?></td>
						</tr>
						<tr>
							<td><b>Speed: </b></td>
							<td><?php echo $_SESSION['storeview_picture'] ?></td>
						</tr>
						<td><b> QTY </b></td>
						<td>
							<input type="text" name="qty" value="">
						</table>
					</div>
					<div align="center">
					<td colspan="2"><input type="submit" name="add_cart" value="Add to cart"></td>
					<a href="store.php"><input type="button" name="back to store" value="back to store"></a>
				</div>
			<?php
			}
			?>
	</body>
</html>