<?php include 'admincheck.php' ?>
<?php
$userid1 = $_GET['userview'];
if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$password = $_POST['password'];
	$level = $_POST['level'];
	$stmt = $connection->prepare("UPDATE `users`
								SET `username` = '$username', `firstname` = '$firstname' ,`lastname` = '$lastname', `md5` = '$password', `level`='$level' WHERE userid = $userid1");
	$stmt->execute();
	header('Location: admin-panel.php');
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Update user</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<?php include('nav.php'); ?>
		<div align="center">
			<p>Level 1: Admin || Level 2: Manager || Level 3: Employee || Level 4: Customer</p>
			<p>Must fill out all values for the textfield</p>
			<form method="post" action="">
				<table id="admintable">
					<tr>
						<th>Catagory</th>
						<th>Current Values</th>
						<th>Update Values</th>
					</tr>
					<tr>
						<td><b>Username: </b></td>
						<td id="username"><?php echo $_SESSION['username'] ?></td>
						<td><input type="text" name="username" id="input"></td>
						<script id="jsbin-javascript">
							var textbox1 = document.getElementById('input');
							var td1 = document.getElementById('username');
							td1.onclick = function (e) {
								e = e || window.event;
								var el =  e.target || e.srcElement;
								if (el.nodeName.toUpperCase() == "TD") {
									textbox1.value += (el.textContent || el.innerText);
									}
							}
						</script>
					</tr>
					<tr>
						<td><b>First Name: </b></td>
						<td id="firstname"><?php echo $_SESSION['firstname'] ?></td>
						<td><input type="text" name="firstname" id="input1"></td>
						<script id="jsbin-javascript">
							var textbox2 = document.getElementById('input1');
							var td2 = document.getElementById('firstname');
							td2.onclick = function (e) {
								e = e || window.event;
								var el =  e.target || e.srcElement;
								if (el.nodeName.toUpperCase() == "TD") {
									textbox2.value += (el.textContent || el.innerText);
									}
							}
						</script>
					</tr>
					<tr>
						<td><b>Last Name: </b></td>
						<td id="lastname"><?php echo $_SESSION['lastname'] ?></td>
						<td><input type="text" name="lastname" id="input2"></td>
						<script id="jsbin-javascript">
							var textbox3 = document.getElementById('input2');
							var td3 = document.getElementById('lastname');
							td3.onclick = function (e) {
								e = e || window.event;
								var el =  e.target || e.srcElement;
								if (el.nodeName.toUpperCase() == "TD") {
									textbox3.value += (el.textContent || el.innerText);
									}
							}
						</script>
					</tr>
					<tr>
						<td><b>MD5: </b></td>
						<td id="password"><?php echo $_SESSION['password'] ?></td>
						<td><input type="text" name="password" id="input3"></td>
						<script id="jsbin-javascript">
							var textbox4 = document.getElementById('input3');
							var td4 = document.getElementById('password');
							td4.onclick = function (e) {
								e = e || window.event;
								var el =  e.target || e.srcElement;
								if (el.nodeName.toUpperCase() == "TD") {
									textbox4.value += (el.textContent || el.innerText);
									}
							}
						</script>
					</tr>
					<tr>
						<td><b>Level: </b></td>
						<td id="level1"><?php echo $_SESSION['level1'] ?></td>
						<td><input type="text" name="level" id="input4"></td>
						<script id="jsbin-javascript">
							var textbox5 = document.getElementById('input4');
							var td5 = document.getElementById('level1');
							td5.onclick = function (e) {
								e = e || window.event;
								var el =  e.target || e.srcElement;
								if (el.nodeName.toUpperCase() == "TD") {
									textbox5.value += (el.textContent || el.innerText);
									}
							}
						</script>
					</tr>
				</table>
				<input type="submit" name="submit" value="Update">
			</form>
		</div>
		
	</body>
</html>