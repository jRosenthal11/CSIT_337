<?php include 'admincheck.php' ?>
<!DOCTYPE html>
<html>
	<head>
		<title>Edit User Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<!-- This code wil be present on all the pages on the site. -->
		<?php include "nav.php"?>
		<!-- ****************************************************** -->
		<!-- Rest of the HTML code goes here. -->
		<?php
		$userid1 = $_GET['userid'];
		$stmt1 = $connection->prepare("SELECT * FROM users WHERE userid = $userid1");
		$stmt1->execute();
		$result1 = $stmt1->fetchAll();
		foreach ($result1 as $result1){
			$_SESSION['userid2'] = $result1['userid'];
			$_SESSION['username'] = $result1['username'];
			$_SESSION['firstname'] = $result1['firstname'];
			$_SESSION['lastname'] = $result1['lastname'];
			$_SESSION['password'] = $result1['md5'];
			$_SESSION['level1'] = $result1['level'];
			}
		?>
		<div align="center">
			<p>Level 1: Admin || Level 2: Manager || Level 3: Employee || Level 4: Customer</p>
			<table id="utable">
				<tr>
					<td><b>User-ID: </b></td>
					<td><?php echo $_SESSION['userid2'] ?></td>
				</tr>
				<tr>
					<td><b>Username: </b></td>
					<td><?php echo $_SESSION['username'] ?></td>
				</tr>
				<tr>
					<td><b>First Name: </b></td>
					<td><?php echo $_SESSION['firstname'] ?></td>
				</tr>
				<tr>
					<td><b>Last Name: </b></td>
					<td><?php echo $_SESSION['lastname'] ?></td>
				</tr>
				<tr>
					<td><b>Password: </b></td>
					<td><?php echo $_SESSION['password'] ?></td>
				</tr>
				<tr>
					<td><b>level: </b></td>
					<td><?php echo $_SESSION['level1'] ?></td>
				</tr>
			</table>
		</div>
		<div align="center">
			<a href="delete.php?userview=<?php echo $_SESSION['userid2'];?>"><input type="button" name="View" value="Delete"></a>
			<a href="update.php?userview=<?php echo $_SESSION['userid2'];?>"><input type="button" name="View" value="Update"></a>
		</div>
	</body>
</html>